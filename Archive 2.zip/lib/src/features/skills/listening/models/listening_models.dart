enum TestState { initial, loading, test, results }
enum PassageLength { short, medium, long }
enum Difficulty { a1, a2, b1, b2, c1, c2, adaptive }